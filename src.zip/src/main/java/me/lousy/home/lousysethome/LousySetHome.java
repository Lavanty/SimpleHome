package me.lousy.home.lousysethome;

import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

class LousySetHome extends JavaPlugin {

    @Override
    public void onEnable() {
        // Plugin startup logic
    }

    @Override
    public void onDisable() {
        // Plugin shutdown logic
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (label.equalsIgnoreCase("sethome") && sender instanceof Player) {
            Player player = (Player) sender;
            player.sendMessage("Home set!");
            player.setBedSpawnLocation(player.getLocation(), true);
            return true;
        } else if (label.equalsIgnoreCase("home") && sender instanceof Player) {
            Player player = (Player) sender;
            player.sendMessage("Teleporting to home!");
            player.teleport(player.getBedSpawnLocation());
            return true;
        }
        return false;
    }
}
